export function requireAdmin(req,res,next) {
  const token = req.get('x-admin-token');
  if (!token || !req.app.locals.adminSessions?.has(token)) return res.status(401).json({error:'Admin session expired. Please log in again.'});
  next();
}
