import test from 'node:test';
import assert from 'node:assert/strict';
import { validateModelAnswer, validateStudentQuestion } from '../services/answerValidator.js';
import { nextFaqId } from '../services/faqStore.js';
import { STARTER_FAQS, NOT_FOUND } from '../utils/constants.js';

test('starter database contains eight records and expected IDs',()=>{assert.equal(STARTER_FAQS.length,8);assert.equal(STARTER_FAQS[1].id,'FAQ-02');});
test('student message validation enforces 1 to 300 trimmed characters',()=>{assert.equal(validateStudentQuestion('   '),false);assert.equal(validateStudentQuestion('hello'),true);assert.equal(validateStudentQuestion('x'.repeat(301)),false);});
test('valid answer preserves verified citation',()=>{assert.deepEqual(validateModelAnswer({found:true,answer:'80% attendance is required.',faq_ids:['FAQ-02']},STARTER_FAQS),{found:true,answer:'80% attendance is required.',faq_ids:['FAQ-02']});});
test('unknown citation is refused',()=>{assert.equal(validateModelAnswer({found:true,answer:'Anything',faq_ids:['FAQ-99']},STARTER_FAQS).answer,NOT_FOUND);});
test('found true with empty citation is refused',()=>{assert.equal(validateModelAnswer({found:true,answer:'Answer',faq_ids:[]},STARTER_FAQS).found,false);});
test('not found always returns no citations',()=>{assert.deepEqual(validateModelAnswer({found:false,answer:'',faq_ids:[]},STARTER_FAQS),{found:false,answer:NOT_FOUND,faq_ids:[]});});
test('next FAQ ID starts at FAQ-09 and advances monotonically',()=>{assert.equal(nextFaqId(STARTER_FAQS),'FAQ-09');assert.equal(nextFaqId([...STARTER_FAQS,{id:'FAQ-12'}]),'FAQ-13');});
