import {useEffect,useRef,useState} from 'react';
import {ArrowUp,Paperclip,ShieldCheck,Sparkles,BookOpen,Clock3,BusFront,GraduationCap,LoaderCircle,Trash2} from 'lucide-react';
import ChatMessage from './ChatMessage';
import {sendQuestion} from '../services/api';
const suggestions=[{text:'What is the attendance requirement?',icon:GraduationCap},{text:'When does the library close?',icon:BookOpen},{text:'How do I submit my FYP proposal?',icon:Sparkles},{text:'When do university buses leave?',icon:BusFront}];
const unavailable='AI service temporarily unavailable. Check your connection or API key and try again.';
export default function ChatWindow({chat,clearChat}){
 const [draft,setDraft]=useState('');const [loading,setLoading]=useState(false);const [error,setError]=useState('');const bottom=useRef(null);const input=useRef(null);
 useEffect(()=>bottom.current?.scrollIntoView({behavior:'smooth'}),[chat.messages,loading]);
 const submit=async(value=draft)=>{const q=value.trim();if(!q){setError('Please enter a message.');return}if(q.length>300){setError('Message cannot exceed 300 characters.');return}if(loading)return;setError('');setDraft('');const userMsg={id:crypto.randomUUID(),role:'user',content:q,timestamp:Date.now()};chat.updateMessages(chat.activeId,m=>[...m,userMsg]);if(chat.active.messages.length===0)chat.updateMessages(chat.activeId,m=>m.map((x,i)=>i===0?x:{...x}));setLoading(true);
  try{const data=await sendQuestion(q);const assistant={id:crypto.randomUUID(),role:'assistant',content:data.answer,faq_ids:data.found?data.faq_ids:[],timestamp:Date.now()};chat.updateMessages(chat.activeId,m=>[...m,assistant]);
  }catch(err){const text=err.response?.data?.error||unavailable;setError(text);setDraft(q);}
  finally{setLoading(false);input.current?.focus()}
 };
 const handleKey=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();submit()}};
 return <main className="chat-main"><header className="topbar"><div><div className="topbar-title">AI Department Help Desk</div><div className="topbar-sub"><span className="status-dot"/> Answers grounded in department FAQs</div></div><button className="clear-btn" onClick={clearChat}><Trash2 size={15}/> Clear chat</button></header>
  <div className="chat-scroll"><div className="chat-content">{chat.active.messages.length===0?<section className="welcome"><div className="welcome-icon"><Sparkles size={25}/></div><div className="eyebrow">YOUR DEPARTMENT, SIMPLIFIED</div><h1>How can I help<br/><span>you today?</span></h1><p>Ask anything about department facilities, academics, exams, projects and more. I’ll find the answer in the official FAQ knowledge base.</p><div className="suggestion-grid">{suggestions.map(({text,icon:Icon})=><button key={text} className="suggestion-card" onClick={()=>submit(text)}><span><Icon size={17}/></span><b>{text}</b><ArrowUp size={15}/></button>)}</div><div className="grounding-note"><ShieldCheck size={16}/> Every answer is backed by a department FAQ citation.</div></section>:<div className="messages">{chat.active.messages.map(m=><ChatMessage key={m.id} message={m}/>) }{loading&&<div className="message-row"><div className="avatar bot-avatar"><BotIcon/></div><div className="typing"><span/><span/><span/> <small>AskSE is checking the FAQs…</small></div></div>}<div ref={bottom}/></div>}</div></div>
  <div className="composer-wrap"><div className="composer"><textarea ref={input} rows="1" value={draft} maxLength={300} onChange={e=>{setDraft(e.target.value);setError('')}} onKeyDown={handleKey} placeholder="Message AskSE…"/><div className="composer-footer"><div className="composer-hint"><ShieldCheck size={13}/> FAQ-grounded answers only <span className="counter">{draft.length}/300</span></div><button className="send-btn" onClick={()=>submit()} disabled={loading||!draft.trim()||draft.length>300} aria-label="Send message">{loading?<LoaderCircle className="spin" size={17}/>:<ArrowUp size={18}/>}</button></div></div>{error&&<div className="input-error">{error}</div>}<div className="disclaimer">AskSE can only answer using the department's approved FAQ records.</div></div>
 </main>
}
function BotIcon(){return <Sparkles size={17}/>}
