# AskSE — AI Department Help Desk

AskSE is a university department help desk that answers student questions **only from the current department FAQ database**. It supports English and Roman Urdu, cites verified FAQ IDs, refuses unsupported questions, and provides FAQ administration and persistent chat history.

## Technology
- Frontend: React, Vite, Tailwind CSS, Lucide React
- Backend: Node.js, Express
- AI: Google Gemini REST API (server-side only)
- Storage: persistent JSON files (`server/data/faqs.json`) and browser localStorage for conversations
- Security: Helmet, rate limiting, request validation, server-side API key, response schema and citation validation

## Requirements
- Node.js 20+ and npm
- A Gemini API key from Google AI Studio for live AI answers

## Installation
1. Extract the ZIP and open a terminal in the `askse` folder.
2. Install root tooling: `npm install`
3. Install backend dependencies: `npm install --prefix server`
4. Install frontend dependencies: `npm install --prefix client`
5. Copy `.env.example` to `server/.env` and set `GEMINI_API_KEY`. Keep this file private; it is ignored by Git.
6. Start both applications: `npm run dev`
7. Open `http://localhost:5173`. The API runs on `http://localhost:5000`.

For a production frontend build: `npm run build`. Start the API with `npm start` from the project root (or `npm start --prefix server`). Configure `CLIENT_ORIGIN` to the deployed frontend origin. The Express server serves the API; deploy the built frontend to a static host or configure your reverse proxy.

## AI configuration
`server/.env` supports `GEMINI_API_KEY`, `GEMINI_MODEL` (default `gemini-2.0-flash`), `PORT`, `CLIENT_ORIGIN`, and `ADMIN_PIN`. The key never goes to the browser. Requests have a 30-second timeout. If the key is missing, invalid, the network fails, or model output is invalid, the API returns a safe service-unavailable response.

The server loads the FAQ JSON from disk for **every chat request**, so additions and deletions are reflected in the next request without a restart. The model receives FAQ records as quoted factual data and must return JSON. The server validates the response and verifies every citation against the latest database. The fixed not-found response is returned by the server when the model cannot ground an answer.

## Admin access
Open **Admin Panel** in the sidebar. Demo PIN: `2026` (configurable through `ADMIN_PIN`). This is a hackathon demonstration gate, not production-grade identity management. Before public deployment, replace it with authenticated accounts, hashed credentials, role-based access control, CSRF protections where applicable, and audit logging.

Admins can add FAQs (question 10–150 characters, answer 10–400 characters, approved category only) and delete records. IDs are assigned sequentially starting at FAQ-09 based on the highest current FAQ ID. The JSON file is written atomically.

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health status |
| GET | `/api/faqs` | List FAQ records |
| POST | `/api/chat` | Grounded AI answer with citations |
| POST | `/api/admin/login` | Verify admin PIN |
| POST | `/api/admin/faqs` | Add an FAQ (requires `x-admin-token`) |
| DELETE | `/api/admin/faqs/:id` | Delete an FAQ (requires `x-admin-token`) |
| POST | `/api/admin/reset` | Restore starter FAQs (requires `x-admin-token`) |

The demo admin token is an in-memory session token; restarting the server logs admins out. Student chat history is stored in browser localStorage with timestamps and can be cleared without affecting FAQs.

## Testing
Run `npm test` from the root (after installing server dependencies). Tests cover starter data, ID generation, input validation, schema validation, citation validation, and persistence helpers. Live Gemini tests require a valid key and should be performed manually with the checklist below.

### Hackathon acceptance checklist
- [ ] Ask attendance → FAQ-02
- [ ] Ask library timings → FAQ-03
- [ ] Ask FYP proposal → FAQ-06
- [ ] Ask bus timings → FAQ-07
- [ ] Ask unrelated question → exact not-found message
- [ ] Ask in Roman Urdu → Roman Urdu answer and correct citation
- [ ] Empty / whitespace / 301-character input rejected
- [ ] Wrong admin PIN rejected; `2026` accepted
- [ ] Add FAQ-09 and verify it is available on the next AI request
- [ ] Delete FAQ and verify it is absent from the next AI context
- [ ] Prompt injection does not reveal instructions or secrets
- [ ] Remove network / use invalid key → graceful AI unavailable message
- [ ] Restart server → FAQ additions/deletions persist
- [ ] Reopen browser → chat history restored
- [ ] Clear chat → FAQ database unchanged

## Team information
Edit `client/src/config/team.js` to configure team name, entry ID, team members, repository URL, and AI model label. Empty placeholders are intentional; no team details are fabricated.

## Important limitations
The provided PIN gate is suitable only for a controlled hackathon demo. For production use, implement real user authentication and authorization. Browser localStorage is device/browser-specific and is not a cross-device chat sync service.
