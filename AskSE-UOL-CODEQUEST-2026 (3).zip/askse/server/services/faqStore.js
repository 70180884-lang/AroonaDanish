import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { STARTER_FAQS } from '../utils/constants.js';
const here = path.dirname(fileURLToPath(import.meta.url));
export const DATA_FILE = path.resolve(here, '../data/faqs.json');
async function writeAtomic(records) {
  await fs.mkdir(path.dirname(DATA_FILE), {recursive:true});
  const temp = `${DATA_FILE}.${process.pid}.tmp`;
  await fs.writeFile(temp, JSON.stringify(records, null, 2), 'utf8');
  await fs.rename(temp, DATA_FILE);
}
export async function readFaqs() {
  try { const parsed = JSON.parse(await fs.readFile(DATA_FILE,'utf8')); return Array.isArray(parsed) ? parsed : []; }
  catch (error) { if (error.code === 'ENOENT') { await writeAtomic(STARTER_FAQS); return structuredClone(STARTER_FAQS); } throw error; }
}
export async function ensureStarterData() {
  try { await fs.access(DATA_FILE); }
  catch { await writeAtomic(STARTER_FAQS); }
}
export async function saveFaqs(records) { await writeAtomic(records); }
export function nextFaqId(records) {
  const max = records.reduce((n, faq) => { const m = /^FAQ-(\d+)$/.exec(faq.id || ''); return m ? Math.max(n, Number(m[1])) : n; }, 8);
  return `FAQ-${String(max+1).padStart(2,'0')}`;
}
