import {useState} from 'react';
import {useChat} from './hooks/useChat';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';
import AdminPage from './pages/AdminPage';
import AboutPage from './pages/AboutPage';
export default function App(){
 const [collapsed,setCollapsed]=useState(false);const [page,setPage]=useState('chat');const chat=useChat();
 const clear=()=>{if(window.confirm('Clear all messages?'))chat.clearChat()};
 return <div className="app-shell"><Sidebar collapsed={collapsed} setCollapsed={setCollapsed} conversations={chat.conversations} activeId={chat.activeId} setActiveId={chat.setActiveId} newChat={()=>{chat.newChat();setPage('chat')}} page={page} setPage={setPage}/>{page==='chat'?<ChatWindow chat={chat} clearChat={clear}/>:page==='admin'?<AdminPage/>:<AboutPage/>}</div>
}
