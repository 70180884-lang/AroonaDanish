/** @type {import('tailwindcss').Config} */
export default {content:['./index.html','./src/**/*.{js,ts,jsx,tsx}'],theme:{extend:{colors:{ink:'#101828',brand:'#4f46e5',mint:'#dff8ef'}}},plugins:[]};
