import { Router } from 'express';
import { readFaqs } from '../services/faqStore.js';
import { askGemini } from '../services/gemini.js';
import { validateModelAnswer, validateStudentQuestion } from '../services/answerValidator.js';
import { AI_UNAVAILABLE } from '../utils/constants.js';
const router=Router();
router.post('/', async (req,res) => {
  const {question}=req.body || {};
  if (typeof question !== 'string' || !question.trim()) return res.status(400).json({error:'Please enter a message.'});
  if (question.length > 300) return res.status(400).json({error:'Message cannot exceed 300 characters.'});
  if (!validateStudentQuestion(question)) return res.status(400).json({error:'Enter a message between 1 and 300 characters.'});
  try {
    const faqs=await readFaqs();
    const raw=await askGemini(question.trim(),faqs);
    const verified=validateModelAnswer(raw,faqs);
    return res.json(verified);
  } catch (error) {
    // Never return provider details, prompts, or credentials to the client.
    console.error('AI request failed:', error?.name === 'AbortError' ? 'timeout' : 'provider unavailable');
    return res.status(503).json({error:AI_UNAVAILABLE});
  }
});
export default router;
