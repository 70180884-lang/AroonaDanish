import { Router } from 'express';
import { readFaqs } from '../services/faqStore.js';
const router = Router();
router.get('/', async (_req,res,next) => { try { const faqs=await readFaqs(); res.json({faqs}); } catch(e){next(e);} });
export default router;
