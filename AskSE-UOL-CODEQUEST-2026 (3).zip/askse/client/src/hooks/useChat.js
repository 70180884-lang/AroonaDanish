import {useEffect,useState} from 'react';
const STORAGE_KEY='askse-conversations-v1';
const makeConversation=()=>({id:crypto.randomUUID?.()||String(Date.now()),title:'New chat',messages:[],updatedAt:Date.now()});
export function useChat(){
 const [conversations,setConversations]=useState(()=>{try{const v=JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]');return Array.isArray(v)&&v.length?v:[makeConversation()]}catch{return [makeConversation()]}});
 const [activeId,setActiveId]=useState(()=>{try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]')?.[0]?.id || null}catch{return null}});
 useEffect(()=>{localStorage.setItem(STORAGE_KEY,JSON.stringify(conversations));},[conversations]);
 const active=conversations.find(c=>c.id===activeId)||conversations[0];
 useEffect(()=>{if(!activeId&&active)setActiveId(active.id)},[activeId,active]);
 const updateMessages=(id,fn)=>setConversations(prev=>prev.map(c=>{if(c.id!==id)return c;const messages=fn(c.messages);const firstUser=messages.find(m=>m.role==='user');return {...c,messages,title:c.title==='New chat'&&firstUser?firstUser.content.slice(0,34):c.title,updatedAt:Date.now()}}));
 const newChat=()=>{const c=makeConversation();setConversations(p=>[c,...p]);setActiveId(c.id);return c.id};
 const clearChat=()=>updateMessages(active.id,()=>[]);
 return {conversations,active,activeId,setActiveId,newChat,updateMessages,clearChat};
}
export const timeLabel=(stamp)=>new Date(stamp).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
