import axios from 'axios';
const api=axios.create({baseURL:import.meta.env.VITE_API_URL || 'http://localhost:5000/api',timeout:35000});
export const getFaqs=async()=> (await api.get('/faqs')).data;
export const sendQuestion=async(question)=> (await api.post('/chat',{question})).data;
export const adminLogin=async(pin)=> (await api.post('/admin/login',{pin})).data;
export const addFaq=async(data,token)=> (await api.post('/admin/faqs',data,{headers:{'x-admin-token':token}})).data;
export const deleteFaq=async(id,token)=> (await api.delete(`/admin/faqs/${encodeURIComponent(id)}`,{headers:{'x-admin-token':token}})).data;
export const resetFaqs=async(token)=> (await api.post('/admin/reset',{}, {headers:{'x-admin-token':token}})).data;
export default api;
