// Configure these values with your actual team information before submission.
export const teamConfig = {
  teamName: 'Add your team name',
  entryId: 'Add your entry ID',
  members: ['Add team member names'],
  githubUrl: '',
  aiModel: 'Gemini 2.0 Flash',
};
